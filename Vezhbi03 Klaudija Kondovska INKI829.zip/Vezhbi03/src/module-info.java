/**
 * 
 */
/**
 * @author User
 *
 */
module Vezhbi03 {
}